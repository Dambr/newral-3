let helper = require('./helper')
const nbc4001k = require("./node_modules/nbc4001k/index.js")
const nfs4002k = require("./node_modules/nfs4002k/index.js")
const nc4003k = require("./node_modules/nc4003k/index.js")

const express = new require('express');
const app = express();
const http = require('http').Server(app);
const fetch = require('node-fetch')
const router = express.Router();
const bodyParser = require('body-parser');
const urlencodedParser = bodyParser.urlencoded({extended: false});
app.use(bodyParser.json())

const parseRTF = require('rtf-parser')
const fs = require('fs')

const path1 = "node_modules/nbc4001k"
const path2 = "node_modules/nfc4002k"
const path3 = "node_modules/nc4003k"
/*text = "первый хотеть надо должный должный должный сделать сделать понимать нужный хорошо читать читать читать оставаться следовать труд личный"
var out = text.split(" ")
var map = "{"
for (i = 0; i < out.length; i+=1){
	map += '"'+ out[i] + '"' + ":" + '"' + i + '"'
	if (i != out.length-1)
	map += ","
}
map += "}"
console.log(JSON.parse(map))*/





app.use('/', router);
app.use(express.static(__dirname + '/'));
router.get('/',function(req,res){
  res.render('index.php');
  //__dirname : It will resolve to your project folder.
});


router.get('/sendingfile',function(req,res){
  console.log('got file'  + res.data);
  //__dirname : It will resolve to your project folder.
});
router.get('/test',function(req,res){
  res.render('test.php');
  //__dirname : It will resolve to your project folder.
});
router.get('/newpage',function(req,res){
  res.render('newpage.php');
  //__dirname : It will resolve to your project folder.
});
router.get('/page',function(req,res){
  res.render('page.php');
  //__dirname : It will resolve to your project folder.
});
router.get('/rtf',function(req,res){
  res.render('rtf.php');
  //__dirname : It will resolve to your project folder.
});

app.post('*', urlencodedParser, function(req,res){
    console.log("POST");
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'origin, content-type, accept');
    console.log(helper(req.body.text, res));
    fs.writeFileSync('node_modules/nbc4001k/solution.json', JSON.stringify(helper(req.body.text, res)), function (err) {
        if (err) return console.log(err);
        console.log('Wroten at 1');
    });
    fs.writeFileSync('node_modules/nfs4002k/solution.json', JSON.stringify(helper(req.body.text, res)), function (err) {
        if (err) return console.log(err);
        console.log('Wroten at 2');
    });
    fs.writeFileSync('node_modules/nc4003k/solution.json', JSON.stringify(helper(req.body.text, res)), function (err) {
        if (err) return console.log(err);
        console.log('Wroten at 3');
    });
    nbc4001k();
    nfs4002k();
    nc4003k();
    // module.exports = nbc4001k.startWorking()
    // nfs4002k.startWorking()
    // nc4003k.startWorking()
    // res.send(JSON.stringify({
    //     data: "message"
    // }));
});
http.listen(8001, 'a0445570.xsph.ru', ()=>{
 console.log("listen");
});
app.post('/post', urlencodedParser, function(req, res){
  res.setHeader('Access-Control-Allow-Origin', '*');
 res.setHeader('Access-Control-Allow-Headers', 'origin, content-type, accept');
 console.log(req.body);
   console.log("вв");
 res.send(JSON.stringify({
  data: "message"
 }));
});

//