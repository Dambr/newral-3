module.exports = (text, RESPONSE) => {
    let keyWords = [
            "первый", "хотеть", "надо", "должный",
            "сделать", "нужный", "понимать", "работа",
            "хорошо", "читать", "оставаться", "начальник",
            "следовать", "труд", "личный"
        ]
    let counts = {
        "первый": 0, 
        "хотеть": 0,
        "надо": 0, 
        "должный": 0,
        "сделать": 0,
        "нужный": 0,
        "понимать": 0,
        "работа": 0,
        "хорошо": 0,
        "читать": 0,
        "оставаться": 0,
        "начальник": 0,
        "следовать": 0,
        "труд": 0,
        "личный": 0
    }
    // text = text.replace('\n', '')
    //             .replace(')', '')
    //             .replace('(', '')
    //             .replace('.', '')
    //             .replace(',', '')
    //             .replace('\"', '')
    //             .replace('\'', '');
    
    text = text.split(' ');
    
    for (let i = 0; i < keyWords.length; i ++){
        for (let j = 0; j < text.length; j ++){
            if (text[j].toLowerCase().includes(keyWords[i].toLowerCase().substring(0, keyWords[i].length - 2))){
                counts[keyWords[i]]++;
            }
        }
    }
    return counts;
}