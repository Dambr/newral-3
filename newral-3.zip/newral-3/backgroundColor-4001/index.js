const mysql = require('mysql');
const connection = mysql.createConnection({
	host : 'localhost',
	user : 'root',
	password : 'root',
	database : 'color', // Менять ЭТО!!!
	insecureAuth : true,
	port : 8889
});
let text;
let size;
let parameters;
let names = [];
function getTdIndex(i, j){
	return size * i + j;
}

// function getColor(r, g, b){
// 	return 'rgb(' + r + ',' + g + ',' + b + ')';
// }

function drawTdColor(i, j, color){
	tds[getTdIndex(i, j)].r = color.r;
	tds[getTdIndex(i, j)].g = color.g;
	tds[getTdIndex(i, j)].b = color.b;
}
function getDistance(vector1, vector2){
	let distance = 0;
	for (let key of names){
		distance += Math.pow((vector1[key] - vector2[key]), 2);
	}
	return distance;
}

function getColorLength(color){
	let len = 0;
	for (let i = 0; i < color.length; i ++){
		len += Math.pow(color[i], 2);
	}
	return Math.sqrt(len);
}

function getColorDeg(color1, color2){
	let deg = 0;
	for (let i = 0; i < color1.length; i ++){
		deg += (color1[i] * color2[i]) / (getColorLength(color1) * getColorLength(color2));
	}
	return deg;
}

// function getColorDistance(color1, color2){
// 	let distance = 0;
// 	for (let i = 0; i < color1.length; i ++){
// 		distance += Math.pow((color1[i] - color2[i]), 2);
// 	}
// 	return Math.sqrt(distance);
// }

function isEqualVectors(vector1, vector2){
	let len = Math.max(vector1.length, vector2.length);
	let sorted1 = vector1.slice().sort();
	let sorted2 = vector2.slice().sort();
	for (let i = 0; i < len; i ++){
		if (sorted1[i] !== sorted2[i]){
			return false;
		}
	}
	return true;
}

// function getColorVector(color){
// 	let colorVector = color.replace('rgb(', '').replace(')', '').split(', ');
// 	for (let i = 0; i < colorVector.length; i ++){
// 		colorVector[i] = Number(colorVector[i]);
// 	}
// 	return colorVector;
// }

function likeMasterVector(color){
	let colorVector = [color.r, color.g, color.b];
	if (isEqualVectors(colorVector, [255, 255, 255])){
		return require('./master_vector')[0].Type;
	}
	let master_color = [];
	for (let i = 0; i < require('./master_vector.json').length; i ++){
		master_color.push([require('./master_vector.json')[i].r, require('./master_vector.json')[i].g, require('./master_vector.json')[i].b]);
	}
	let distances = [];
	for (let i = 0; i < master_color.length; i ++){
		distances.push(getColorDeg(colorVector, master_color[i]));
	}
	let minDistance = Math.max(...distances);
	let minIndex    = distances.indexOf(minDistance);

	return require('./master_vector.json')[minIndex].Type; 
}

function projection(vector){
	let distances = [];
	let koord     = [];
	for (let i = 0; i < size; i ++){
		for (let j = 0; j < size; j ++){
			distances.push(getDistance(vector, tds[getTdIndex(i, j)]));
			koord.push([i, j]);
		}
	}
	let minDistance = Math.min(...distances);
	let minKoord    = koord[distances.indexOf(minDistance)];

	let problem = likeMasterVector({
		r: tds[getTdIndex(...minKoord)].r,
		g: tds[getTdIndex(...minKoord)].g,
		b: tds[getTdIndex(...minKoord)].b
	});

	console.log(problem); // Вывод того самого свойства в консоль. 
			// Можно организовать вывод в файл или что то еще с этим делать
}


new Promise(function(response, reject){
	connection.query("SELECT * FROM test", function(err, res){
		if (err) throw err;
		text = res;
		size = Math.floor(Math.sqrt(res.length));
		parameters = require('./parameters');
		tds = [];
		response();
	});
})
.then(
	() => {
		// Создаем поле и инициализируем его
		for (let i = 0; i < parameters.parameters.length; i ++){
			names.push(parameters.parameters[i].name);
		}
		for (let i = 0; i < size; i ++){
			for (let j = 0; j < size; j ++){
				let _td = {};
				_td.id = getTdIndex(i, j);
				for (let key = 0; key < parameters.parameters.length; key ++){
					_td[parameters.parameters[key].name] = 0;
				}
				_td.r = 255;
				_td.g = 255;
				_td.b = 255;
				tds.push(_td);
			}
		}

		for (let i = 0; i < size; i ++){
			for (let j = 0; j < size; j ++){
				let title = [];
				for (let key of names){
					tds[text[getTdIndex(i, j)].id][key] = text[getTdIndex(i, j)][key];
					title.push(key + ": " + text[getTdIndex(i, j)][key]);
				}
				tds[text[getTdIndex(i, j)].id].r = text[getTdIndex(i, j)].r;
				tds[text[getTdIndex(i, j)].id].g = text[getTdIndex(i, j)].g;
				tds[text[getTdIndex(i, j)].id].b = text[getTdIndex(i, j)].b;

				tds[text[getTdIndex(i, j)].id].title = title.join("\n");
			}
		}

		// Покраска поля
		for (let i = 0; i < size; i ++){
			for (let j = 0; j < size; j ++){
				drawTdColor(i, j, {
					r: tds[getTdIndex(i, j)].r, 
					g: tds[getTdIndex(i, j)].g, 
					b: tds[getTdIndex(i, j)].b
				});
			}
		}
		

		// В эту функцию передаются данные из файла solution
		projection(require('./solution.json'));
	}
)
.then(
	() => {
		connection.end();
	}
);
